//= require jquery_ujs
//= require autocomplete-rails
//= require jquery.cycle.all.min

